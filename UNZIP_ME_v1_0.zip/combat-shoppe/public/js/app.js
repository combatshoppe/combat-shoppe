let modules = ['ngRoute', 'appRoutes', 'MainCtrl', 'SimulatorCtrl',
	'HomebrewCtrl', 'DataUtilsModule', 'DataModule', 'UiModule',
	'SimulatorUtils', 'SimulatorModule', 'WindowUtilsModule',
	'WindowModule'];

angular.module('combatShoppeApp', modules);
