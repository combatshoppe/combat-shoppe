/**
 * HomebrewCtrl.js
 * A controller for the homebrew page
 */

angular.module('HomebrewCtrl', []).controller('HomebrewController', function($scope) {
	$scope.tagline = 'Welcome to Homebrew section!';
});
