/**
 * MainCtrl.js
 * A controller for the / page
 */

angular.module('MainCtrl', []).controller('MainController', function($scope) {
	$scope.tagline = 'Welcome to 5e Combat Shoppe angular app!';
});
